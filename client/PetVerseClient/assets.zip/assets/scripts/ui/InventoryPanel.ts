import { _decorator, Component, instantiate, Node, Prefab } from 'cc';
import NetworkManager from '../network/NetworkManager';
import PlayerData from '../data/PlayerData';
import { InventoryItemSlot } from './InventoryItemSlot';

const { ccclass, property } = _decorator;

@ccclass('InventoryPanel')
export class InventoryPanel extends Component {

    @property(Prefab)
    itemSlotPrefab: Prefab | null = null;

    @property(Node)
    content: Node | null = null;

    onEnable() {
        this.node.on('INVENTORY_REFRESH', this.refreshInventory, this);
        void this.loadInventory();
    }

    onDisable() {
        this.node.off('INVENTORY_REFRESH', this.refreshInventory, this);
    }

    async loadInventory() {
        const res = await NetworkManager.get('/inventory', PlayerData.token);
        const list = res?.items || res?.data || [];

        this.clearContent();

        if (!Array.isArray(list)) return;

        for (const item of list) {
            const node = instantiate(this.itemSlotPrefab!);
            const slot = node.getComponent(InventoryItemSlot);

            if (!slot) {
                node.destroy();
                continue;
            }

            slot.setData(item);
            this.content?.addChild(node);
        }
    }

    async refreshInventory() {
        await this.loadInventory();
    }

    private clearContent() {
        if (!this.content) return;

        for (const c of this.content.children) {
            c.destroy();
        }
    }
}