import { _decorator, Component, Label, Button } from 'cc';
import NetworkManager from '../network/NetworkManager';

const { ccclass, property } = _decorator;

@ccclass('InventoryItemSlot')
export class InventoryItemSlot extends Component {

    @property(Label)
    nameLabel: Label | null = null;

    @property(Label)
    countLabel: Label | null = null;

    private data: any = null;

    init(data: any) {
        this.data = data;

        if (this.nameLabel) {
            this.nameLabel.string = data.itemCode || '';
        }

        if (this.countLabel) {
            this.countLabel.string = 'x' + data.quantity;
        }
    }

    async onUseClick() {

        if (!this.data) return;

        await NetworkManager.post('/inventory/use', {
            itemCode: this.data.itemCode
        });

        console.log('使用成功:', this.data.itemCode);
    }
}