import { _decorator, Component, Node, Prefab, instantiate, Label } from 'cc';
import NetworkManager from '../network/NetworkManager';

const { ccclass, property } = _decorator;

@ccclass('ShopPanel')
export class ShopPanel extends Component {

    @property(Node)
    content: Node | null = null;

    @property(Prefab)
    itemPrefab: Prefab | null = null;

    async loadShop() {

        const res = await NetworkManager.get('/shop/items');

        const list = res?.items || res?.data || [];

        if (!this.content || !this.itemPrefab) {
            console.warn('ShopPanel 未绑定');
            return;
        }

        this.content.removeAllChildren();

        for (const item of list) {

            const node = instantiate(this.itemPrefab);
            this.content.addChild(node);

            const nameLabel = node.getChildByName('NameLabel')?.getComponent(Label);
            const countLabel = node.getChildByName('CountLabel')?.getComponent(Label);

            if (nameLabel) nameLabel.string = item?.name || item?.itemCode || '';
            if (countLabel) countLabel.string = String(item?.price ?? 0) + '金币';
        }
    }

    onEnable() {
        void this.loadShop();
    }
}