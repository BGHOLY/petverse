import ApiConfig from './ApiConfig';

export default class NetworkManager {

    public static async get(
        url: string,
        token: string = '',
    ): Promise<any> {
        return this.request('GET', url, undefined, token);
    }

    public static async post(
        url: string,
        data: any = {},
        token: string = '',
    ): Promise<any> {
        return this.request('POST', url, data, token);
    }

    private static async request(
        method: 'GET' | 'POST',
        url: string,
        data?: any,
        token: string = '',
    ): Promise<any> {
        const fallback = { success: false, data: [] };

        try {
            const headers: Record<string, string> = {};

            if (method === 'POST') {
                headers['Content-Type'] = 'application/json';
            }

            if (token) {
                headers.Authorization = `Bearer ${token}`;
            }

            const response = await fetch(ApiConfig.BASE_URL + url, {
                method,
                headers,
                body: method === 'POST' ? JSON.stringify(data || {}) : undefined,
            });

            if (!response.ok) {
                return fallback;
            }

            try {
                const json = await response.json();
                return json;
            } catch {
                return fallback;
            }
        } catch {
            return fallback;
        }
    }
}
